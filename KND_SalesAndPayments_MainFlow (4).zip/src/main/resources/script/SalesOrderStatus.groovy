import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;

def Message processData(Message message) {
    // Parse the JSON body
    def body = message.getBody(String);
    def jsonSlurper = new JsonSlurper();
    def jsonObject = jsonSlurper.parseText(body);
    
    // Check if SalesOrder has a value
    if (jsonObject.SalesOrder) {
        // Set the header
        message.setHeader("SalesOrderStatus", "SalesOrder is created");
    }
    
    return message;
}
