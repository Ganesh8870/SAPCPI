// Import the Message class from the correct package
import com.sap.gateway.ip.core.customdev.processor.Message

// Define a function to process your message
def processData(Message message) {
    // Example processing logic here
    println "Processing message: ${message}"
    // Perform any required operations on the message object
    return message
}

// Example usage in your SAP integration scenario
try {
    // Instantiate your Message object (replace with your actual logic)
    def message = new Message()
    
    // Example: Set message body (replace with your actual message handling logic)
    message.setBody("<your-original-xml-payload>") // Set your original XML payload
    
    // Process the message using your function
    def processedMessage = processData(message)
    
    // Optionally, access the processed message data
    def modifiedPayload = processedMessage.getBody(String)
    println "Modified Payload: $modifiedPayload"
} catch (Exception e) {
    println "Error processing message: ${e.message}"
    e.printStackTrace()
}
