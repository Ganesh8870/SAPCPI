import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    
    def messageLog = messageLogFactory.getMessageLog(message);
    if(messageLog != null){

        // Retrieve the first header (po_number)
        def po_number = message.getHeaders().get("HighSalaryEmp");        
        if(po_number != null){
            // Log the first custom header property
            messageLog.addCustomHeaderProperty("Greaterthan50K", po_number);        
        }

        // Retrieve the second header (emp_id)
        def emp_id = message.getHeaders().get("LowSalaryEmp");        
        if(emp_id != null){
            // Log the second custom header property
            messageLog.addCustomHeaderProperty("Lessthan50K", emp_id);        
        }

        // Retrieve the third header (salary_amount)
        def salary_amount = message.getHeaders().get("CurrectSalary");        
        if(salary_amount != null){
            // Log the third custom header property
            messageLog.addCustomHeaderProperty("Exactly50K", salary_amount);        
        }
    }
    
    return message;
}
