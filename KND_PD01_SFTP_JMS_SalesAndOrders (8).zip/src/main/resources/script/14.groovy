import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    // Extract the XML content from the message body
    def xmlString = message.getBody(String) as String
    
    // Check if the XML string is not empty or null
    if (xmlString == null || xmlString.trim().isEmpty()) {
        throw new Exception("The XML content is empty or null.")
    }

    // Clean up the XML string by removing any non-XML content from the beginning
    xmlString = xmlString.trim()
    def xmlStartIndex = xmlString.indexOf('<?xml')
    if (xmlStartIndex == -1) {
        xmlStartIndex = xmlString.indexOf('<')
    }
    if (xmlStartIndex > 0) {
        xmlString = xmlString.substring(xmlStartIndex)
    }

    // Parse the XML string
    def xml = new groovy.util.XmlSlurper().parseText(xmlString)

    // Extract the namespace URI for the prefix "d"
    def namespaceURI = xml.declareNamespace(d: xml.namespaceURI())

    // Extract the <d:Customer> value
    def customerValue = xml.'d:Customer'.text()
    
    // Check if customerValue is found
    if (customerValue == null) {
        throw new Exception("The <d:Customer> element is not found in the XML content.")
    }
    
    // Set the value in headers
    message.setHeader('CustomerHeaderValue', customerValue)
    message.setHeader('ShipToAddress', customerValue)
    
    // Return the modified message
    return message
}
