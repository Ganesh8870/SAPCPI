import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.XmlSlurper
import groovy.xml.Namespace

def Message processData(Message message) {
    // Get the XML content from the message body
    def body = message.getBody(String)
    
    // Parse the XML content
    def xml = new XmlSlurper().parseText(body)
    
    // Define namespaces
    def ns = new Namespace("http://schemas.microsoft.com/ado/2007/08/dataservices", 'd')
    
    // Extract the value from the <d:Customer> element
    def customerValue = xml.'**'.find { it.name() == 'Customer' && it.namespaceURI() == ns.uri() }?.text()
    
    // Set the customer value in a header
    if (customerValue) {
        message.setHeader("CustomerHeaderValue", customerValue)
    }
    
    return message
}
