import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

Message processData(Message message) {
    // Parse the JSON payload
    def body = message.getBody(String)
    def jsonSlurper = new JsonSlurper()
    def jsonObject = jsonSlurper.parseText(body)
    
    // Check if SalesOrder has a value and set the header accordingly
    if (jsonObject.SalesOrder) {
        message.setHeader("SalesOrderStatus", "SalesOrder is created")
    }
    
    // Retrieve the value from the header
    def newPayload = message.getHeader("JSONPayloadCapture", String)
    
    // Replace the 'payload' field in the JSON object
    jsonObject.payload = newPayload
    
    // Serialize the modified JSON back to a string
    def modifiedJson = JsonOutput.toJson(jsonObject)
    
    // Set the modified JSON as the new message body
    message.setBody(modifiedJson)
    
    return message
}
