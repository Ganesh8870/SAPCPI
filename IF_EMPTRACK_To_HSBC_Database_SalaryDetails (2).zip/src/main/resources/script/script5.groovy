import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput
import java.text.SimpleDateFormat
import java.util.TimeZone

def Message processData(Message message) {
    // Fetch headers and properties safely with defaults
    def headers = message.getHeaders()
    def properties = message.getProperties()

    // Fetch dynamic values, default to "N/A" if not available
    def interfaceId = headers?.get("InterfaceID") ?: "N/A"
    def camelId = headers?.get("CamelId") ?: "N/A"
    def exceptionMessage = headers?.get("exception") ?: "No exception details"

    // Capture dynamic email address from property
    def mailAddress = properties?.get("MailAddress") ?: "misganesh69@gmail.com"

    // Developer Name
    def developerName = "Ganesh"

    // Set time zone to IST (Asia/Kolkata)
    def istTimeZone = TimeZone.getTimeZone("Asia/Kolkata")
    def currentDateFormatter = new SimpleDateFormat("MM-dd-yyyy")
    def currentTimeFormatter = new SimpleDateFormat("HH:mm:ss")
    currentDateFormatter.setTimeZone(istTimeZone)
    currentTimeFormatter.setTimeZone(istTimeZone)

    // Current Date and Time in IST
    def currentDate = currentDateFormatter.format(new Date())
    def currentTime = currentTimeFormatter.format(new Date())

    // Build the HTML content
    def htmlContent = """
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>SAP CPI - Exception Details</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                background-color: #f4f4f9;
                margin: 0;
                padding: 20px;
            }
            .container {
                background-color: #ffffff;
                border: 1px solid #ddd;
                border-radius: 8px;
                padding: 20px;
                width: 70%;
                margin: 0 auto;
            }
            .header {
                background-color: #6F8FAF;
                color: white;
                padding: 10px;
                border-radius: 5px;
                text-align: center;
            }
            table {
                width: 100%;
                margin-top: 20px;
                border-collapse: collapse;
            }
            th, td {
                padding: 12px;
                text-align: left;
                border: 1px solid #ddd;
            }
            th {
                background-color: #f4f4f4;
            }
            .footer {
                font-size: 12px;
                text-align: center;
                margin-top: 20px;
                color: #777;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h2>Exception Details</h2>
            </div>
            <table>
                <tr>
                    <th>Interface ID</th>
                    <td>${interfaceId}</td>
                </tr>
                <tr>
                    <th>Date</th>
                    <td>${currentDate}</td>
                </tr>
                <tr>
                    <th>Time</th>
                    <td>${currentTime} IST</td>
                </tr>
                <tr>
                    <th>IFlow Name</th>
                    <td>${camelId}</td>
                </tr>
                <tr>
                    <th>Exception Message</th>
                    <td>${exceptionMessage}</td>
                </tr>
                <tr>
                    <th>Developer</th>
                    <td>${developerName}</td>
                </tr>
            </table>
            <div class="footer">
                <p>If you have any questions, please contact support.</p>
                <p>&copy; 2024 JSK Computers</p>
            </div>
        </div>
    </body>
    </html>
    """

    // Construct final JSON payload
    def payload = [
        "Subject": "SAP CPI - Error Message: ${exceptionMessage}", // Dynamically include exception message
        "ToRecipients": [
            [
                "EmailAddress": [
                    "Address": mailAddress,
                    "Name": "Recipient"
                ]
            ]
        ],
        "CcRecipients": [
            [
                "EmailAddress": [
                    "Address": mailAddress,
                    "Name": "Recipient"
                ]
            ]
        ],
        "Body": [
            "Content": htmlContent,
            "ContentType": "html"
        ]
    ]

    // Convert payload to JSON string
    def jsonOutput = JsonOutput.toJson(payload)

    // Set the JSON payload in the message body
    message.setBody(jsonOutput)

    return message
}
