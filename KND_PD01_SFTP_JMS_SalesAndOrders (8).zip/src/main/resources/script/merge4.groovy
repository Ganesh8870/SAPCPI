import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.*

def Message processData(Message message) {
    // Get the first XML snippet from the message body
    def body = message.getBody(String)
    
    // Split the body to get individual XML parts
    def parts = body.split("\n\n")
    
    if (parts.size() < 2) {
        throw new Exception("Expected two XML parts separated by two newlines, but found less.")
    }
    
    // Extract individual XML snippets
    def xml1 = parts[0].trim()
    def xml2 = parts[1].trim()
    
    // Parse the XML snippets
    def parser = new XmlParser()
    def salesOrder = parser.parseText(xml1)
    def items = parser.parseText(xml2)
    
    // Append items to sales order
    salesOrder.append(items)
    
    // Convert the combined XML back to a string
    def writer = new StringWriter()
    def nodePrinter = new XmlNodePrinter(new PrintWriter(writer))
    nodePrinter.setPreserveWhitespace(true)
    nodePrinter.print(salesOrder)
    def result = writer.toString()
    
    // Set the modified payload back to the message
    message.setBody(result)
    
    return message
}
