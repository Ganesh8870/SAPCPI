import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    // Get the incoming XML body
    def body = message.getBody(java.lang.String) as String
    
    // Parse the XML
    def xml = new XmlSlurper().parseText(body)
    
    // Extract fields for the header
    def salesOrderType = xml.SalesOrderType.text()
    def soldToParty = xml.SoldToParty.text()
    def salesOrganization = xml.SalesOrganization.text()
    def distributionChannel = xml.DistributionChannel.text()
    def organizationDivision = xml.OrganizationDivision.text()
    def purchaseOrderByCustomer = xml.PurchaseOrderByCustomer.text()
    def completeDeliveryIsDefined = xml.CompleteDeliveryIsDefined.text()
    def partnerFunction = xml._Partner.PartnerFunction.text()
    def customer = xml._Partner.Customer.text()
    
    // Construct the new XML structure as a string with 'Half_Payload' as the root
    def xmlString = """
            <SalesOrderType>${salesOrderType}</SalesOrderType>
            <SoldToParty>${soldToParty}</SoldToParty>
            <SalesOrganization>${salesOrganization}</SalesOrganization>
            <DistributionChannel>${distributionChannel}</DistributionChannel>
            <OrganizationDivision>${organizationDivision}</OrganizationDivision>
            <PurchaseOrderByCustomer>${purchaseOrderByCustomer}</PurchaseOrderByCustomer>
            <CompleteDeliveryIsDefined>${completeDeliveryIsDefined}</CompleteDeliveryIsDefined>
            <_Partner>
                <PartnerFunction>${partnerFunction}</PartnerFunction>
                <Customer>${customer}</Customer>
            </_Partner>
        
    """
    
    // Set the new XML structure with 'Half_Payload' header as the message body
    message.setHeader("SalesOrderDetails", xmlString)
    
    return message
}
