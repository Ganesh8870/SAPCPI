import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    // Get XML input from the message body
    def body = message.getBody(String) as String;
    def sqlStatement = new StringBuffer();

    // Start the INSERT query
    sqlStatement.append("INSERT INTO doc.ganesh (employeeid, employeename, company, ifsccode, branchname, salaryamount, accountnumber)\nVALUES\n");

    // Parse XML input
    def xml = new XmlSlurper().parseText(body);

    def values = [] // Temporary list to hold each row's values

    // Loop through each employee node and prepare rows
    xml.employee.each { employee ->
        def row = new StringBuilder();
        row.append("(");
        row.append(employee.employeeid.text() ? employee.employeeid.text() : "NULL").append(", "); // employeeid
        row.append(employee.employeename.text() ? "'${employee.employeename.text().replace("'", "''")}'" : "NULL").append(", "); // employeename
        row.append(employee.company.text() ? "'${employee.company.text().replace("'", "''")}'" : "NULL").append(", "); // company
        row.append(employee.ifsccode.text() ? "'${employee.ifsccode.text().replace("'", "''")}'" : "NULL").append(", "); // ifsccode
        row.append(employee.branchname.text() ? "'${employee.branchname.text().replace("'", "''")}'" : "NULL").append(", "); // branchname
        row.append(employee.salaryamount.text() ? employee.salaryamount.text() : "NULL").append(", "); // salaryamount
        row.append(employee.accountnumber.text() ? "'${employee.accountnumber.text().replace("'", "''")}'" : "NULL"); // accountnumber
        row.append(")");
        values.add(row.toString());
    }

    // Combine all rows with commas
    sqlStatement.append(values.join(",\n"));
    sqlStatement.append(";"); // End the query with a semicolon

    // Set the generated SQL statements as the message body
    message.setBody(sqlStatement.toString());
    return message;
}
