import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    // Get the body of the message as a string
    def body = message.getBody(String)

    // Parse the JSON payload
    def jsonSlurper = new JsonSlurper()
    def jsonPayload = jsonSlurper.parseText(body)

    // Extract the error message
    def errorMessage = jsonPayload.error.message

    // Set the error message to a header
    message.setHeader("ErrorMessage", errorMessage)

    return message
}
