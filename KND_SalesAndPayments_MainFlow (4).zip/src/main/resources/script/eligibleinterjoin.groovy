import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

Message processData(Message message) {
    // Parse the JSON payload
    def body = message.getBody(String)
    def jsonParser = new JsonSlurper()
    def jsonObject = jsonParser.parseText(body)
    
    // Retrieve the value from the header
    def newPayload = message.getHeader(" ", String)
    
    // Replace the 'payload' field in the JSON object
    jsonObject.payload = newPayload
    
    // Serialize the modified JSON back to a string
    def modifiedJson = JsonOutput.toJson(jsonObject)
    
    // Set the modified JSON as the new message body
    message.setBody(modifiedJson)
    
    return message
}
