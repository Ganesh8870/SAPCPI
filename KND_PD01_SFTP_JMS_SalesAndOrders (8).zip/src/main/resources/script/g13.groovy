import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    // Get the XML content from the message body
    def body = message.getBody(String)
    
    // Parse the XML content using XmlSlurper
    def xml = new XmlSlurper().parseText(body)
    
    // Access the value of <d:Customer>
    def customerValue = xml.'**'.find { node -> node.name() == 'd:Customer' }.text()
    
    // Set the extracted value as a message header
    message.setHeader('CustomerHeaderValue', customerValue)
    
    // Return the modified message
    return message
}
