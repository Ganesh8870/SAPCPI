import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper

def Message processData(Message message) {
    // Get the XML payload from the message
    def body = message.getBody(String)
    
    // Remove XML declaration if present
    body = body.replaceFirst(/\<\?xml.*?\?\>/, "")
    
    // Parse the XML
    def xml = new XmlSlurper().parseText(body)
    
    // Extract values of the specified elements and form the XML string
    def salesOrderType = "<SalesOrderType>${xml.SalesOrderType.text()}</SalesOrderType>"
    def soldToParty = "<SoldToParty>${xml.SoldToParty.text()}</SoldToParty>"
    def salesOrganization = "<SalesOrganization>${xml.SalesOrganization.text()}</SalesOrganization>"
    def distributionChannel = "<DistributionChannel>${xml.DistributionChannel.text()}</DistributionChannel>"
    def organizationDivision = "<OrganizationDivision>${xml.OrganizationDivision.text()}</OrganizationDivision>"
    def purchaseOrderByCustomer = "<PurchaseOrderByCustomer>${xml.PurchaseOrderByCustomer.text()}</PurchaseOrderByCustomer>"
    def completeDeliveryIsDefined = "<CompleteDeliveryIsDefined>${xml.CompleteDeliveryIsDefined.text()}</CompleteDeliveryIsDefined>"
    def partnerFunction = "<PartnerFunction>${xml._Partner.PartnerFunction.text()}</PartnerFunction>"
    def customer = "<Customer>${xml._Partner.Customer.text()}</Customer>"
    
    // Concatenate all elements into one XML string
    def concatenatedXml = salesOrderType + soldToParty + salesOrganization + distributionChannel + organizationDivision + purchaseOrderByCustomer + completeDeliveryIsDefined + partnerFunction + customer
    
    // Set the concatenated XML string as a header
    message.setHeader("ConcatenatedXmlHeader", concatenatedXml)
    
    return message
}
