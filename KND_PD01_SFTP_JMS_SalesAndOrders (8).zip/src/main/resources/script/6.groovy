import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.XmlSlurper

// Extract the message object
def message = message

// Extract the value of <d:Customer> from XML content
def xmlString = message.getBody(java.lang.String) as String
def xml = new XmlSlurper().parseText(xmlString)
def customerValue = xml.'**'.find { it.name() == 'Customer' }.text()

// Set the value in a header
message.setHeader('CustomerHeaderValue', customerValue)

// Return the modified message
return message
