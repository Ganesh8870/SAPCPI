import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.XmlUtil

def Message processData(Message message) {
    // Retrieve header XML
    def headerXml = '''<SalesOrder>
<SalesOrderType>TA</SalesOrderType><SoldToParty>null</SoldToParty><SalesOrganization>KR01</SalesOrganization><DistributionChannel>10</DistributionChannel><OrganizationDivision>00</OrganizationDivision><PurchaseOrderByCustomer>PDCPI01</PurchaseOrderByCustomer><CompleteDeliveryIsDefined>true</CompleteDeliveryIsDefined><_Partner><PartnerFunction>WE</PartnerFunction><Customer>5000103</Customer></_Partner>
</SalesOrder>'''

    // Retrieve payload XML
    def payloadXml = '''<SalesOrderItems>
<_Item><Product>440000102</Product><RequestedQuantity>6</RequestedQuantity><RequestedQuantityISOUnit>EA</RequestedQuantityISOUnit><StorageLocation>1003</StorageLocation><Plant>2020</Plant><_ItemPricingElement><ConditionType>ZDIS</ConditionType><ConditionRateRatio>0</ConditionRateRatio><ConditionRateRatioISOUnit>P1</ConditionRateRatioISOUnit></_ItemPricingElement><_ItemPricingElement><ConditionType>ZPR0</ConditionType><ConditionRateAmount>5</ConditionRateAmount><ConditionCurrency>USD</ConditionCurrency></_ItemPricingElement></_Item><_Item><Product>440000102</Product><RequestedQuantity>6</RequestedQuantity><RequestedQuantityISOUnit>EA</RequestedQuantityISOUnit><StorageLocation>1003</StorageLocation><Plant>2020</Plant><_ItemPricingElement><ConditionType>ZDIS</ConditionType><ConditionRateRatio>0</ConditionRateRatio><ConditionRateRatioISOUnit>P1</ConditionRateRatioISOUnit></_ItemPricingElement><_ItemPricingElement><ConditionType>ZPR0</ConditionType><ConditionRateAmount>5</ConditionRateAmount><ConditionCurrency>USD</ConditionCurrency></_ItemPricingElement></_Item>
</SalesOrderItems>'''

    // Parse header XML
    def headerXmlRoot = new XmlParser().parseText(headerXml)
    
    // Parse payload XML
    def payloadXmlRoot = new XmlParser().parseText(payloadXml)
    
    // Append payload items to header XML
    payloadXmlRoot._Item.each { item ->
        headerXmlRoot.append(item)
    }
    
    // Convert combined XML back to string
    def combinedXml = XmlUtil.serialize(headerXmlRoot)

    // Set combined XML as new payload
    message.setBody(combinedXml)
    
    return message
}
