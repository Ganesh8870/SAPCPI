import com.sap.gateway.ip.core.customdev.util.Message
import com.sap.gateway.ip.core.customdev.util.MessageAccessor

def Message processData(Message message) {
    // Get the XML content from the message body
    def body = message.getBody(String)
    
    // Use SAP CPI's XML handling utilities to work with XML content
    def xml = MessageAccessor.getXml(body)
    
    // Access XML elements and attributes as needed
    def customerValue = xml.'**'.find { it.name() == 'Customer' }.text()
    
    // Set the extracted value as a message property
    message.setProperty('CustomerValue', customerValue)
    
    // Return the modified message
    return message
}
