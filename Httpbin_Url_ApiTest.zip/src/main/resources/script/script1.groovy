import TokenValidator

def token = "Hxk1kGfp4FJXaaIVfw7DcEq4YJiz"

// Use the TokenValidator class from the other script
def isExpired = TokenValidator.isTokenExpired(token)

if (isExpired) {
    message.setBody("Token is expired.")
} else {
    message.setBody("Token is valid.")
}
