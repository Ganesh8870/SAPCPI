import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper

def Message processData(Message message) {
    // Get the XML payload from the message body
    def body = message.getBody(java.lang.String) as String

    // Parse the XML
    def xml = new XmlSlurper().parseText(body)

    // Define namespaces
    def m = new groovy.xml.Namespace('http://schemas.microsoft.com/ado/2007/08/dataservices/metadata', 'm')
    def d = new groovy.xml.Namespace('http://schemas.microsoft.com/ado/2007/08/dataservices', 'd')

    // Extract the Customer value
    def customer = xml.'**'.find { it.name() == 'properties' }?.'**'.find { it.name() == 'Customer' }?.text()

    // Set the Customer field and value as headers
    if (customer) {
        message.setHeader("CustomerHeaderField", "Customer")
        message.setHeader("CustomerHeaderValue", customer)
    } else {
        // Log a warning if the Customer value is not found
        def messageLog = messageLogFactory.getMessageLog(message)
        messageLog.addWarning("Customer value not found in the XML payload")
    }

    // Return the modified message object
    return message
}
