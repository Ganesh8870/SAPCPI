import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

Message processData(Message message) {
    // Get the body of the message as a string
    def body = message.getBody(String)
    
    try {
        // Parse the JSON response
        def jsonSlurper = new JsonSlurper()
        def jsonResponse = jsonSlurper.parseText(body)
        
        // Check if the error node is present in the JSON response
        def errorExists = jsonResponse.containsKey('error')
        
        if (errorExists) {
            // Extract the error message
            def errorMessage = jsonResponse.error.message
            
             // Update the value of the 'message' field
              json.message = errorReason
            
            // Set the header element 'errorMessage' with the error message
            message.setHeader('errorMessage', errorMessage)
    
        } else {
            // If 'error' node is not present, set a default error message
            message.setHeader('errorMessage', 'Purchase order number in document number: 2562 already exists')
            
        }
        
    } catch (Exception e) {
        // Log the exception
        e.printStackTrace()
        
        // Set ErrorReason header with the error message
        message.setHeader('errorMessage', 'Purchase order number in document number: 2562 already exists')
     
    }
    
    // Return the original message with the header set
    return message
}

