import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    // Get the message body as a string (if available)
    String messageBody = message.getBody(String);
    
    // Check if the message body is null or empty
    int contentLength = (messageBody != null) ? messageBody.length() : 0;
    
    // Set the content-length property
    message.setProperty("content-length", contentLength.toString());
    
    // Return the message
    return message;
}
