// Import required classes
import com.sap.aii.adapter.xi.dispatch.Message
import com.sap.aii.adapter.xi.dispatch.MessageBuilder
import org.apache.commons.io.FilenameUtils

// Get the incoming message content (file)
def message = message.getBody(String) // assuming it's a string, adapt if it's byte array
def fileName = message.getHeaders().get("CamelFileName") // Retrieve the file name if available

// Set default values for XML or CSV properties
def fileType = "unknown"

// Check if fileName is available
if (fileName) {
    // Check file extension (XML or CSV)
    def extension = FilenameUtils.getExtension(fileName).toLowerCase()

    if (extension == "xml") {
        fileType = "XML"
    } else if (extension == "csv") {
        fileType = "CSV"
    } else {
        fileType = "unknown" // Avoid unsupported files
    }
} else if (message.trim().isEmpty()) {
    // Handle empty message (avoid empty file)
    fileType = "empty"
} else {
    // Check file content if extension is missing
    if (message.trim().startsWith("<")) {
        fileType = "XML"
    } else if (message.trim().contains(",")) {
        fileType = "CSV"
    } else {
        fileType = "unknown"
    }
}

// Set property with the identified file type
message.setProperty("fileType", fileType)

// Optionally log the file type
messageLog.setStringProperty("fileType", fileType)
