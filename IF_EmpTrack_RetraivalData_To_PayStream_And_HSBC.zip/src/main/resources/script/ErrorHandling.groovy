import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonOutput;
import java.text.SimpleDateFormat;
import java.util.TimeZone;

def Message processData(Message message) {
    // Fetch headers and properties
    def headers = message.getHeaders()
    def properties = message.getProperties()

    // Fetch dynamic values safely
    def FlowName = headers?.get("IflowName") ?: "N/A"
    def messageid = headers?.get("MessageId") ?: "N/A"
    def exceptionMessage = properties?.get("CamelExceptionCaught") ?: "No exception details"

    // Developer Name
    def developerName = "Prasanna"

    // Set timezone to IST
    def istTimeZone = TimeZone.getTimeZone("Asia/Kolkata")
    def dateTimeFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    dateTimeFormatter.setTimeZone(istTimeZone)

    // Current timestamp in IST
    def currentTimestamp = dateTimeFormatter.format(new Date())

    // HTML email body content
    def htmlContent = """
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>SAP CPI - Error in Integration Flow</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                background-color: #f4f4f9;
                margin: 0;
                padding: 20px;
            }
            .container {
                background-color: #ffffff;
                border: 1px solid #ddd;
                border-radius: 8px;
                padding: 20px;
                width: 600px;
                margin: 0 auto;
            }
            .header {
                background-color: #6F8FAF;
                color: white;
                padding: 10px;
                border-radius: 5px;
                text-align: center;
            }
            ul {
                list-style: none;
                padding: 0;
            }
            li {
                margin: 5px 0;
            }
            .button {
                display: inline-block;
                background-color: #6F8FAF;
                color: white;
                padding: 10px 20px;
                text-decoration: none;
                border-radius: 5px;
                margin-top: 20px;
            }
            .button:hover {
                background-color: #5e7b97;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h2>Alert Notification</h2>
            </div>
            <div class="content">
                <p><strong>Dear User,</strong></p>
                <p>This is an alert regarding an error in the CPI Integration Flow. Please take the necessary action.</p>
                <p><strong>Details:</strong></p>
                <ul>
                    <li><strong>Developer Name:</strong> ${developerName}</li>
                    <li><strong>Timestamp:</strong> ${currentTimestamp}</li>
                    <li><strong>Flow Name:</strong> ${FlowName}</li>
                    <li><strong>Message ID:</strong> ${messageid}</li>
                    <li><strong>Error Details:</strong> ${exceptionMessage}</li>
                </ul>
                <a href="https://2c94591etrial.integrationsuite-trial.cfapps.ap21.hana.ondemand.com/shell/monitoring/Messages/%7B%22identifier%22%3A%22AGdNVi3t-8WqLBm8CD_sVMwAYO3y%22%7D" class="button">View Details</a>
            </div>
        </div>
    </body>
    </html>
    """

    // JSON payload structure
    def payload = [
        "Subject": "SAP CPI - Error in Integration Flow",
        "ToRecipients": [
            [
                "EmailAddress": [
                    "Address": "karthikramadurai.cpi@gmail.com",
                    "Name": "Karthik Ramadurai"
                ]
            ]
        ],
        "CcRecipients": [
            [
                "EmailAddress": [
                    "Address": "prasannavengatesh733@gmail.com",
                    "Name": "PrasannaVengatesh"
                ]
            ]
        ],
        "Body": [
            "Content": htmlContent,
            "ContentType": "html"
        ]
    ]

    // Convert payload to JSON string
    def jsonOutput = JsonOutput.toJson(payload)

    // Set JSON payload in the message body
    message.setBody(jsonOutput)

    return message
}
