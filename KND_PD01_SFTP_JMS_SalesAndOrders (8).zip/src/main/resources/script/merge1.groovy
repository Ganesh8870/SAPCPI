import groovy.xml.*

// First XML snippet
def xml1 = '''<SalesOrder>
<SalesOrderType>TA</SalesOrderType>
<SoldToParty>null</SoldToParty>
<SalesOrganization>KR01</SalesOrganization>
<DistributionChannel>10</DistributionChannel>
<OrganizationDivision>00</OrganizationDivision>
<PurchaseOrderByCustomer>PDCPI01</PurchaseOrderByCustomer>
<CompleteDeliveryIsDefined>true</CompleteDeliveryIsDefined>
<_Partner>
    <PartnerFunction>WE</PartnerFunction>
    <Customer>5000103</Customer>
</_Partner>
</SalesOrder>'''

// Second XML snippet
def xml2 = '''<_Items>
<_Item>
    <Product>440000102</Product>
    <RequestedQuantity>6</RequestedQuantity>
    <RequestedQuantityISOUnit>EA</RequestedQuantityISOUnit>
    <StorageLocation>1003</StorageLocation>
    <Plant>2020</Plant>
    <_ItemPricingElement>
        <ConditionType>ZDIS</ConditionType>
        <ConditionRateRatio>0</ConditionRateRatio>
        <ConditionRateRatioISOUnit>P1</ConditionRateRatioISOUnit>
    </_ItemPricingElement>
    <_ItemPricingElement>
        <ConditionType>ZPR0</ConditionType>
        <ConditionRateAmount>5</ConditionRateAmount>
        <ConditionCurrency>USD</ConditionCurrency>
    </_ItemPricingElement>
</_Item>
<_Item>
    <Product>440000102</Product>
    <RequestedQuantity>6</RequestedQuantity>
    <RequestedQuantityISOUnit>EA</RequestedQuantityISOUnit>
    <StorageLocation>1003</StorageLocation>
    <Plant>2020</Plant>
    <_ItemPricingElement>
        <ConditionType>ZDIS</ConditionType>
        <ConditionRateRatio>0</ConditionRateRatio>
        <ConditionRateRatioISOUnit>P1</ConditionRateRatioISOUnit>
    </_ItemPricingElement>
    <_ItemPricingElement>
        <ConditionType>ZPR0</ConditionType>
        <ConditionRateAmount>5</ConditionRateAmount>
        <ConditionCurrency>USD</ConditionCurrency>
    </_ItemPricingElement>
</_Item>
</_Items>'''

def parser = new XmlParser()
def salesOrder = parser.parseText(xml1)
def items = parser.parseText(xml2)

salesOrder.append(items)

def printer = new XmlNodePrinter(new PrintWriter(System.out))
printer.setPreserveWhitespace(true)
printer.print(salesOrder)
