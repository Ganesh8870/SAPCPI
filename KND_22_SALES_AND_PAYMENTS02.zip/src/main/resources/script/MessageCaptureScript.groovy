import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;

Message processData(Message message) {
    // Get the incoming payload
    def body = message.getBody(String);
   
    // Parse the JSON payload
    def jsonSlurper = new JsonSlurper();
    def jsonObject = jsonSlurper.parseText(body);
   
    // Get all headers
    def headers = message.getHeaders();
   
    // Get the value of the JMS_Payload header
    def jmsPayload = headers.get("JMS_Payload");
   
    // Get the value of the SalesOrder header
    def salesOrder = headers.get("SalesOrder");
   
    // Replace the value of the "payload" field
    jsonObject.payload = jmsPayload;
   
    // Store the SalesOrder header value in the "Salesorder" field
    jsonObject.Salesorder = salesOrder;
   
    // Clear the values of "headstatus" and "Status" fields
    jsonObject.headstatus = "";
    jsonObject.Status = "";
   
    // Set the "message" field to "SalesOrder was created"
    jsonObject.message = "SalesOrder already created";
   
    // Convert the modified JSON object back to a string
    def jsonOutput = JsonOutput.toJson(jsonObject);
   
    // Set the modified JSON as the message body
    message.setBody(jsonOutput);
   
    return message;
}