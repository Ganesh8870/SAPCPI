import com.sap.gateway.ip.core.customdev.util.Message

// Define the process method which SAP CPI invokes
def Message processData(Message message) {
    // Get the JSON payload from the incoming message
    def jsonPayload = message.getBody(String.class)
    
    // Parse the JSON string into a Groovy map
    def payload = new groovy.json.JsonSlurper().parseText(jsonPayload)
    
    // Modify specific fields as requested
    payload.CompleteDeliveryIsDefined = true  // Set boolean value directly
    
    // Iterate over _Item array to update nested fields
    payload._Item.each { item ->
        item.RequestedQuantity = item.RequestedQuantity.toInteger()  // Convert to integer
        
        // Check if _ItemPricingElement exists and is not null
        if (item._ItemPricingElement) {
            item._ItemPricingElement.each { pricingElement ->
                // Convert to integer if not null
                if (pricingElement.ConditionRateRatio) {
                    pricingElement.ConditionRateRatio = pricingElement.ConditionRateRatio.toInteger()
                }
                if (pricingElement.ConditionRateAmount) {
                    pricingElement.ConditionRateAmount = pricingElement.ConditionRateAmount.toInteger()
                }
            }
        }
    }
    
    // Convert modified payload back to JSON string
    def modifiedJsonPayload = new groovy.json.JsonBuilder(payload).toPrettyString()
    
    // Set the modified JSON payload back into the message body
    message.setBody(modifiedJsonPayload)
    
    // Return the modified message
    return message
}
