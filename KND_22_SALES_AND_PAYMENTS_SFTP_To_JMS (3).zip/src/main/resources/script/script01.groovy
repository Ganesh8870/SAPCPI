import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper

def Message processData(Message message) {
    // Get the XML payload from the message body
    def body = message.getBody(java.lang.String) as String

    // Parse the XML
    def xml = new XmlSlurper().parseText(body)

    // Define namespaces
    def m = new groovy.xml.Namespace('http://schemas.microsoft.com/ado/2007/08/dataservices/metadata', 'm')
    def d = new groovy.xml.Namespace('http://schemas.microsoft.com/ado/2007/08/dataservices', 'd')

    // Extract the Customer value
    def Product = xml.'**'.find { it.name() == 'properties' }?.'**'.find { it.name() == 'Product' }?.text()

    // Set the Customer field and value as headers
    if (Product) {
        message.setHeader("CustomerField", "Product")
        message.setHeader("Product", Product)
    }else
    {""
        message.setHeader("Product", "ProductNotFound")
    }

    // Return the modified message object
    return message
}
