import com.sap.gateway.ip.core.customdev.util.Message
import java.util.HashMap

def Message processData(Message message) {
    def messageBody = message.getBody(java.lang.String)

    // Split the message body into lines
    def lines = messageBody.split('\n')

    // Initialize the XML StringBuilder
    def xmlBuilder = new StringBuilder()

    // Append the root element
    xmlBuilder.append('<SalesPayments>')

    // Track if we're inside a VendorData element
    def insideVendorData = false

    // Loop through each line
    lines.each { line ->
        def parts = line.split(';')
        if (parts[0] == 'V') {
            // Close the previous VendorData element if necessary
            if (insideVendorData) {
                xmlBuilder.append('</SalesPayment>')
            }
            // Start a new VendorData for each 'V' line
            xmlBuilder.append('<SalesPayment>')
            xmlBuilder.append('<SalesPaymentHeaderDetails>')
            parts.eachWithIndex { value, index ->
                switch (index) {
                    case 0:
                        xmlBuilder.append("<TableReference>${value}</TableReference>")
                        break
                    case 1:
                        xmlBuilder.append("<SalesSite>${value}</SalesSite>")
                        break
                    case 2:
                        xmlBuilder.append("<Invoice_Category>${value}</Invoice_Category>")
                        break
                    case 3:
                        xmlBuilder.append("<InvoiceNumber>${value}</InvoiceNumber>")
                        break
                    case 4:
                        xmlBuilder.append("<BillToCustomer>${value}</BillToCustomer>")
                        break
                    case 5:
                        xmlBuilder.append("<Currency>${value}</Currency>")
                        break
                    case 6:
                        xmlBuilder.append("<InvoiceDate>${value}</InvoiceDate>")
                        break
                    case 7:
                        xmlBuilder.append("<ShipToAddressCode>${value}</ShipToAddressCode>")
                        break
                    case 8:
                        xmlBuilder.append("<StockTransactionType>${value}</StockTransactionType>")
                        break
                    case 9:
                        xmlBuilder.append("<ShipSite>${value}</ShipSite>")
                        break
                    case 10:
                        xmlBuilder.append("<X3JournalEntryCode>${value}</X3JournalEntryCode>")
                        break
                }
            }
            xmlBuilder.append('</SalesPaymentHeaderDetails>') // Close the Vendor tag here
            insideVendorData = true // We're now inside a VendorData element
        } else if (parts[0] == 'D') {
            // Add Item for each 'D' line
            xmlBuilder.append('<SalesPaymentItemDetails>')
            parts.eachWithIndex { value, index ->
                switch (index) {
                    case 0:
                        xmlBuilder.append("<TableReference>${value}</TableReference>")
                        break
                    case 1:
                        xmlBuilder.append("<Product>${value}</Product>")
                        break
                    case 2:
                        xmlBuilder.append("<UOM>${value}</UOM>")
                        break
                    case 3:
                        xmlBuilder.append("<Quantity>${value}</Quantity>")
                        break
                    case 4:
                        xmlBuilder.append("<PricePerUOM>${value}</PricePerUOM>")
                        break
                    case 5:
                        xmlBuilder.append("<Discount1>${value}</Discount1>")
                        break
                    case 6:
                        xmlBuilder.append("<Discount2>${value}</Discount2>")
                        break
                    case 7:
                        xmlBuilder.append("<SalesRepID>${value}</SalesRepID>")
                        break
                }
            }
            xmlBuilder.append('</SalesPaymentItemDetails>')
        }
    }

    // Close the last VendorData element if necessary
    if (insideVendorData) {
        xmlBuilder.append('</SalesPayment>')
    }

    // Append the closing root element
    xmlBuilder.append('</SalesPayments>')

    // Set the XML output to the message body
    message.setBody(xmlBuilder.toString())

    return message
}