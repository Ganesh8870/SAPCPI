import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def messageBody = message.getBody(java.lang.String)
    def lines = messageBody.split('\n')

    // Initialize the XML StringBuilder
    def xmlBuilder = new StringBuilder()

    // Append the root element
    xmlBuilder.append('<CustomerPayments>')

    // Track if we're inside a CustomerPayment element
    def insideCustomerPayment = false

    // Loop through each line
    lines.each { line ->
        def parts = line.split(';')
        if (parts[0] == 'P') {
            // Close the previous CustomerPayment element if necessary
            if (insideCustomerPayment) {
                xmlBuilder.append('</CustomerPayment>')
            }
            // Start a new CustomerPayment for each 'P' line
            xmlBuilder.append('<CustomerPayment>')
            xmlBuilder.append('<CustomerPaymentHeaderDetails>')
            parts.eachWithIndex { value, index ->
                switch (index) {
                    case 0:
                        xmlBuilder.append("<TableReference>${value}</TableReference>")
                        break
                    case 1:
                        xmlBuilder.append("<PaymentX>${value}</PaymentX>")
                        break
                    case 2:
                        xmlBuilder.append("<TransactionCode>${value}</TransactionCode>")
                        break
                    case 3:
                        xmlBuilder.append("<Customer>${value}</Customer>")
                        break
                    case 4:
                        xmlBuilder.append("<ChartOfAccountsCode>${value}</ChartOfAccountsCode>")
                        break
                    case 5:
                        xmlBuilder.append("<GLAccount>${value}</GLAccount>")
                        break
                    case 6:
                        xmlBuilder.append("<PayByBranch>${value}</PayByBranch>")
                        break
                    case 7:
                        xmlBuilder.append("<PaymentMethod>${value}</PaymentMethod>")
                        break
                    case 8:
                        xmlBuilder.append("<SalesSite>${value}</SalesSite>")
                        break
                    case 9:
                        xmlBuilder.append("<BankCode>${value}</BankCode>")
                        break
                    case 10:
                        xmlBuilder.append("<Currency>${value}</Currency>")
                        break
                    case 11:
                        xmlBuilder.append("<Check>${value}</Check>")
                        break
                    case 12:
                        xmlBuilder.append("<PaymentAmount>${value}</PaymentAmount>")
                        break
                    case 13:
                        xmlBuilder.append("<PaymentDate>${value}</PaymentDate>")
                        break
                }
            }
            xmlBuilder.append('</CustomerPaymentHeaderDetails>')
            insideCustomerPayment = true // We're now inside a CustomerPayment element
        } else if (parts[0] == 'D') {
            // Add Item for each 'D' line
            xmlBuilder.append('<CustomerPaymentItemDetails>')
            parts.eachWithIndex { value, index ->
                switch (index) {
                    case 0:
                        xmlBuilder.append("<TableReference>${value}</TableReference>")
                        break
                    case 1:
                        xmlBuilder.append("<Destination>${value}</Destination>")
                        break
                    case 2:
                        xmlBuilder.append("<ChartsOfAccounts>${value}</ChartsOfAccounts>")
                        break
                    case 3:
                        xmlBuilder.append("<GLAccount>${value}</GLAccount>")
                        break
                    case 4:
                        xmlBuilder.append("<Customer>${value}</Customer>")
                        break
                    case 5:
                        xmlBuilder.append("<DocumentType>${value}</DocumentType>")
                        break
                    case 6:
                        xmlBuilder.append("<Invoice>${value}</Invoice>")
                        break
                    case 7:
                        xmlBuilder.append("<Empty1>${value}</Empty1>")
                        break
                    case 8:
                        xmlBuilder.append("<CustomerX>${value}</CustomerX>")
                        break
                    case 9:
                        xmlBuilder.append("<Empty2>${value}</Empty2>")
                        break
                    case 10:
                        xmlBuilder.append("<SalesSite>${value}</SalesSite>")
                        break
                    case 11:
                        xmlBuilder.append("<Currency>${value}</Currency>")
                        break
                    case 12:
                        xmlBuilder.append("<Amount>${value}</Amount>")
                        break
                    case 13:
                        xmlBuilder.append("<Empty3>${value}</Empty3>")
                        break
                    case 14:
                        xmlBuilder.append("<Quantity>${value}</Quantity>")
                        break
                }
            }
            xmlBuilder.append('</CustomerPaymentItemDetails>')
        } else if (parts[0] == 'A') {
            // Add Item for each 'A' line
            xmlBuilder.append('<CustomerPaymentItem1Details>')
            parts.eachWithIndex { value, index ->
                switch (index) {
                    case 0:
                        xmlBuilder.append("<TableReference>${value}</TableReference>")
                        break
                    case 1:
                        xmlBuilder.append("<DimensionType>${value}</DimensionType>")
                        break
                    case 2:
                        xmlBuilder.append("<DimensionValue>${value}</DimensionValue>")
                        break
                    case 3:
                        xmlBuilder.append("<DimensionTypeX>${value}</DimensionTypeX>")
                        break
                    case 4:
                        xmlBuilder.append("<DimensionValueX>${value}</DimensionValueX>")
                        break
                    case 5:
                        xmlBuilder.append("<DimensionTypeY>${value}</DimensionTypeY>")
                        break
                    case 6:
                        xmlBuilder.append("<DimensionValueY>${value}</DimensionValueY>")
                        break
                    case 7:
                        xmlBuilder.append("<DimensionTypeZ>${value}</DimensionTypeZ>")
                        break
                    case 8:
                        xmlBuilder.append("<Customer>${value}</Customer>")
                        break
                    case 9:
                        xmlBuilder.append("<Amount>${value}</Amount>")
                        break
                    case 10:
                        xmlBuilder.append("<Quantity>${value}</Quantity>")
                        break
                }
            }
            xmlBuilder.append('</CustomerPaymentItem1Details>')
        }
    }

    // Close the last CustomerPayment element if necessary
    if (insideCustomerPayment) {
        xmlBuilder.append('</CustomerPayment>')
    }

    // Append the closing root element
    xmlBuilder.append('</CustomerPayments>')

    // Set the XML output to the message body
    message.setBody(xmlBuilder.toString())

    return message
}
