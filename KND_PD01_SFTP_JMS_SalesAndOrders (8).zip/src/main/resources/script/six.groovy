import com.sap.gateway.ip.core.customdev.util.Message

def processData(Message message) {
    // Get the XML content from the message body
    def body = message.getBody(String)

    // Parse the XML content using XmlSlurper
    def xml = new XmlSlurper().parseText(body)

    // Define the namespace mappings if necessary
    def namespaces = [
        m: 'http://schemas.microsoft.com/ado/2007/08/dataservices/metadata',
        d: 'http://schemas.microsoft.com/ado/2007/08/dataservices'
    ]

    // Access the value of <d:Customer>
    def customerValue = xml.'**'.find { node ->
        node.name() == 'd:Customer' && node.namespaceURI == namespaces.d
    }?.text()

    // Debug output to check the customerValue
    println "Customer Value found: $customerValue"

    // Set the extracted value as a message header
    if (customerValue != null && !customerValue.isEmpty()) {
        message.setHeader('CustomerHeaderValue', customerValue)
    } else {
        // Handle case where <d:Customer> value is not found or empty
        message.setHeader('CustomerHeaderValue', null)  // Optionally handle or log this scenario
    }

    // Return the modified message
    return message
}
