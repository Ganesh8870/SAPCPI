import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper

def Message processData(Message message) {
    // Get the XML payload from the message
    def body = message.getBody(String)
    
    // Remove XML declaration if present
    body = body.replaceFirst(/\<\?xml.*?\?\>/, "")
    
    // Parse the XML
    def xml = new XmlSlurper().parseText(body)
    
    // Extract values of the specified elements
    def salesOrderType = xml.SalesOrderType.text()
    def soldToParty = xml.SoldToParty.text()
    def salesOrganization = xml.SalesOrganization.text()
    def distributionChannel = xml.DistributionChannel.text()
    def organizationDivision = xml.OrganizationDivision.text()
    def purchaseOrderByCustomer = xml.PurchaseOrderByCustomer.text()
    def completeDeliveryIsDefined = xml.CompleteDeliveryIsDefined.text()
    def partnerFunction = xml._Partner.PartnerFunction.text()
    def customer = xml._Partner.Customer.text()
    
    // Set the extracted values as headers
    message.setHeader("SalesOrderTypeHeader", salesOrderType)
    message.setHeader("SoldToPartyHeader", soldToParty)
    message.setHeader("SalesOrganizationHeader", salesOrganization)
    message.setHeader("DistributionChannelHeader", distributionChannel)
    message.setHeader("OrganizationDivisionHeader", organizationDivision)
    message.setHeader("PurchaseOrderByCustomerHeader", purchaseOrderByCustomer)
    message.setHeader("CompleteDeliveryIsDefinedHeader", completeDeliveryIsDefined)
    message.setHeader("PartnerFunctionHeader", partnerFunction)
    message.setHeader("CustomerHeader", customer)
    
    return message
}
