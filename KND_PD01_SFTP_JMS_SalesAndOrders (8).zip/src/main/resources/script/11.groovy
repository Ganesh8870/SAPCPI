import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    // Extract the XML content from the message body
    def xmlString = message.getBody(String) as String
    
    // Check if the XML string is not empty or null
    if (xmlString == null || xmlString.trim().isEmpty()) {
        throw new Exception("The XML content is empty or null.")
    }

    // Clean up the XML string by removing any non-XML content from the beginning
    xmlString = xmlString.trim().replaceFirst("^([\\W]+)<", "<")
    
    // Parse the XML string
    def xml = new groovy.util.XmlSlurper().parseText(xmlString)
    
    // Extract the <d:Customer> value
    def customerValue = xml.'**'.find { it.name() == 'Customer' }?.text()
    
    // Check if customerValue is found
    if (customerValue == null) {
        throw new Exception("The <d:Customer> element is not found in the XML content.")
    }
    
    // Set the value in headers
    message.setHeader('CustomerHeaderValue', customerValue)
    message.setHeader('ShipToAddress', customerValue)
    
    // Return the modified message
    return message
}
