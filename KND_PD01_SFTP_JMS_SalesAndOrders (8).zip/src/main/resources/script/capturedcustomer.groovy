def xml = '''
<feed xmlns="http://www.w3.org/2005/Atom" xmlns:m="http://schemas.microsoft.com/ado/2007/08/dataservices/metadata" xmlns:d="http://schemas.microsoft.com/ado/2007/08/dataservices" xml:base="https://my407935-api.s4hana.cloud.sap/sap/opu/odata/sap/API_BUSINESS_PARTNER/">
    <id>https://my407935-api.s4hana.cloud.sap/sap/opu/odata/sap/API_BUSINESS_PARTNER/A_BusinessPartner</id>
    <title type="text">A_BusinessPartner</title>
    <updated>2024-06-25T11:26:41Z</updated>
    <author><name/></author>
    <link href="A_BusinessPartner" rel="self" title="A_BusinessPartner"/>
    <entry>
        <id>https://my407935-api.s4hana.cloud.sap/sap/opu/odata/sap/API_BUSINESS_PARTNER/A_BusinessPartner('5000101')</id>
        <title type="text">A_BusinessPartner('5000101')</title>
        <updated>2024-06-25T11:26:41Z</updated>
        <category term="API_BUSINESS_PARTNER.A_BusinessPartnerType" scheme="http://schemas.microsoft.com/ado/2007/08/dataservices/scheme"/>
        <link href="A_BusinessPartner('5000101')" rel="edit" title="A_BusinessPartnerType"/>
        <link href="A_BusinessPartner('5000101')/to_AddressIndependentEmail" rel="http://schemas.microsoft.com/ado/2007/08/dataservices/related/to_AddressIndependentEmail" type="application/atom+xml;type=feed" title="to_AddressIndependentEmail"/>
        <!-- More links omitted for brevity -->
        <content type="application/xml">
            <m:properties xmlns:m="http://schemas.microsoft.com/ado/2007/08/dataservices/metadata" xmlns:d="http://schemas.microsoft.com/ado/2007/08/dataservices">
                <d:BusinessPartner>5000101</d:BusinessPartner>
                <d:Customer>5000101</d:Customer>
                <!-- More properties omitted for brevity -->
            </m:properties>
        </content>
    </entry>
</feed>
'''

// Parse the XML string
def parsedXml = new XmlSlurper().parseText(xml)

// Extract the value of d:Customer
def customerValue = parsedXml
    .entry
    .content
    .'m:properties'
    .'d:Customer'
    .text()

// Print the extracted value
println "Customer value: $customerValue"
