import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
    // Get XML input from the message body
    def body = message.getBody(java.lang.String) as String;
    def sqlStatement = new StringBuffer();

    // Generate the SELECT query to retrieve column details
    sqlStatement.append("SELECT column_name, data_type, character_maximum_length, is_nullable ")
    sqlStatement.append("FROM information_schema.columns ")
    sqlStatement.append("WHERE table_name = 'ganesh' AND table_schema = 'doc';\n\n");

    // Parse XML input
    def xml = new XmlSlurper().parseText(body);

    // Loop through each employee node and generate SQL INSERT statements
    xml.employee.each { employee ->
        sqlStatement.append("INSERT INTO ganesh (employeeid, employeename, company, ifsccode, branchname, salaryamount, accountnumber) VALUES (");
        sqlStatement.append(employee.employeeid.text()).append(", "); // employeeid (integer)
        sqlStatement.append("'").append(employee.employeename.text()).append("', "); // employeename (text)
        sqlStatement.append("'").append(employee.company.text()).append("', "); // company (text)
        sqlStatement.append("'").append(employee.ifsccode.text()).append("', "); // ifsccode (text)
        sqlStatement.append("'").append(employee.branchname.text()).append("', "); // branchname (text)
        sqlStatement.append(employee.salaryamount.text()).append(", "); // salaryamount (numeric)
        sqlStatement.append("'").append(employee.accountnumber.text()).append("'"); // accountnumber (text)
        sqlStatement.append(");\n");
    }

    // Set the generated SQL statements as the message body
    message.setBody(sqlStatement.toString());

    return message;
}
