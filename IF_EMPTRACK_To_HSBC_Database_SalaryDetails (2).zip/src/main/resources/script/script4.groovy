import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    // Access the message log and body
    def body = message.getBody(java.lang.String) as String;
    def messageLog = messageLogFactory.getMessageLog(message);
    def logger = message.getProperty("Enable_Logger");

    // Logical Attachment Names
    String logNamePayload = "EmpTrack_MainPayload";           // Main payload being processed
    String logNameError = "Error_Payload_Details";            // Error payload during failure
    String logNameErrorDescription = "Error_Description";     // Detailed error description

    // Error-related placeholders
    def errorPayload = message.getProperty("ErrorPayload") ?: "No Error Payload Available";
    def errorDescription = message.getProperty("ErrorDescription") ?: "No Error Description Available";

    if (messageLog != null && logger == "true") {
        // Attach the main payload (normal processing)
        messageLog.setStringProperty("Logging#1", "Logging Payload During Error");
        messageLog.addAttachmentAsString(logNamePayload, body, "text/plain");
        
        // Log error details and payloads
        messageLog.addAttachmentAsString(logNameError, errorPayload, "text/plain");
        messageLog.addAttachmentAsString(logNameErrorDescription, errorDescription, "text/plain");
    }

    return message;
}
