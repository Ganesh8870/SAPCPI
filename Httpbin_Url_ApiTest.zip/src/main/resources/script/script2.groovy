/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en-US/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en-US/index.html */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    //Body
   

def token = "Hxk1kGfp4FJXaaIVfw7DcEq4YJiz"

// Use the TokenValidator class from the other script
def isExpired = TokenValidator.isTokenExpired(token)

if (isExpired) {
    message.setBody("Token is expired.")
} else {
    message.setBody("Token is valid.")
}
class TokenValidator {

    // Method to decode a JWT token and return its payload
    static Map parseJwt(String token) {
        def parts = token.split('\\.')
        if (parts.length != 3) {
            throw new IllegalArgumentException("Invalid JWT token format.")
        }
        byte[] decodedPayload = Base64.decoder.decode(parts[1])
        String payloadString = new String(decodedPayload)
        return new groovy.json.JsonSlurper().parseText(payloadString)
    }
}
}