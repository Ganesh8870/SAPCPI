import com.sap.gateway.ip.core.customdev.processor.MessageImpl

// Define your integration logic function
def processData(MessageImpl message) {
    // Extract the payload from the incoming message
    def payload = message.getBody(java.lang.String) as String
    
    // Original XML snippets (replace with your actual XML payloads)
    def xml1 = '''
        <SalesOrderType>TA</SalesOrderType>
        <SoldToParty>null</SoldToParty>
        <SalesOrganization>KR01</SalesOrganization>
        <DistributionChannel>10</DistributionChannel>
        <OrganizationDivision>00</OrganizationDivision>
        <PurchaseOrderByCustomer>PDCPI01</PurchaseOrderByCustomer>
        <CompleteDeliveryIsDefined>true</CompleteDeliveryIsDefined>
        <_Partner>
            <PartnerFunction>WE</PartnerFunction>
            <Customer>5000103</Customer>
        </_Partner>
    '''

    def xml2 = '''
        <_Item>
            <Product>440000102</Product>
            <RequestedQuantity>6</RequestedQuantity>
            <RequestedQuantityISOUnit>EA</RequestedQuantityISOUnit>
            <StorageLocation>1003</StorageLocation>
            <Plant>2020</Plant>
            <_ItemPricingElement>
                <ConditionType>ZDIS</ConditionType>
                <ConditionRateRatio>0</ConditionRateRatio>
                <ConditionRateRatioISOUnit>P1</ConditionRateRatioISOUnit>
            </_ItemPricingElement>
            <_ItemPricingElement>
                <ConditionType>ZPR0</ConditionType>
                <ConditionRateAmount>5</ConditionRateAmount>
                <ConditionCurrency>USD</ConditionCurrency>
            </_ItemPricingElement>
        </_Item>
        <_Item>
            <Product>440000102</Product>
            <RequestedQuantity>6</RequestedQuantity>
            <RequestedQuantityISOUnit>EA</RequestedQuantityISOUnit>
            <StorageLocation>1003</StorageLocation>
            <Plant>2020</Plant>
            <_ItemPricingElement>
                <ConditionType>ZDIS</ConditionType>
                <ConditionRateRatio>0</ConditionRateRatio>
                <ConditionRateRatioISOUnit>P1</ConditionRateRatioISOUnit>
            </_ItemPricingElement>
            <_ItemPricingElement>
                <ConditionType>ZPR0</ConditionType>
                <ConditionRateAmount>5</ConditionRateAmount>
                <ConditionCurrency>USD</ConditionCurrency>
            </_ItemPricingElement>
        </_Item>
    '''

    // Merge XML snippets into a single XML structure
    def mergedXml = """
        <Root>
            ${xml1}
            ${xml2}
        </Root>
    """

    // Set the merged XML as the new payload
    message.setBody(mergedXml)

    // Return the modified message
    return message
}

// Example usage in CPI flow
try {
    // Instantiate a new MessageImpl object (replace with actual logic to get message)
    def message = new MessageImpl()
    message.setBody("<initial-payload>") // Replace with your initial XML payload
    def processedMessage = processData(message)
    def mergedPayload = processedMessage.getBody(java.lang.String) as String
    println "Merged Payload: ${mergedPayload}"
} catch (Exception e) {
    println "Error processing message: ${e.message}"
    e.printStackTrace()
}
