@Grab(group='org.postgresql', module='postgresql', version='42.5.4')  // PostgreSQL JDBC dependency

import groovy.sql.Sql

// Database connection details
def jdbcUrl = 'jdbc:postgresql://hsbc-bank.eks1.eu-west-1.aws.cratedb.net:5432/crate'
def user = 'admin'
def password = 'S..v_)dnJ_pDH9*25(lz_KhT'

// Example employee data (use your actual data here)
def employees = [
    [employeeId: 1, employeeName: "Noah Rodriguez", company: "Boeing", ifscCode: "IFSC1038", branchName: "IFSC1038", salaryAmount: 108500, accountNumber: 1896159542],
    [employeeId: 2, employeeName: "Henry Morgan", company: "Citigroup", ifscCode: "IFSC1440", branchName: "IFSC1440", salaryAmount: 115250, accountNumber: 2623161711],
    [employeeId: 3, employeeName: "Scott Ramos", company: "Walt Disney", ifscCode: "IFSC1173", branchName: "IFSC1173", salaryAmount: 113000, accountNumber: 3633930138],
    [employeeId: 4, employeeName: "Alexander Hall", company: "Novartis", ifscCode: "IFSC4224", branchName: "IFSC4224", salaryAmount: 113750, accountNumber: 3804143424],
    [employeeId: 5, employeeName: "Jeremy White", company: "Chevron", ifscCode: "IFSC3765", branchName: "IFSC3765", salaryAmount: 113750, accountNumber: 2320925284],
    [employeeId: 6, employeeName: "Noah Hernandez", company: "Procter & Gamble", ifscCode: "IFSC1939", branchName: "IFSC1939", salaryAmount: 101000, accountNumber: 5158868861],
    [employeeId: 7, employeeName: "Jesse Morris", company: "Novartis", ifscCode: "IFSC3001", branchName: "IFSC3001", salaryAmount: 105500, accountNumber: 2109219814],
    [employeeId: 8, employeeName: "Ryan Hughes", company: "Merck", ifscCode: "IFSC5893", branchName: "IFSC5893", salaryAmount: 108500, accountNumber: 2186559830],
    [employeeId: 9, employeeName: "Jerry Parker", company: "Bank of China", ifscCode: "IFSC8670", branchName: "IFSC8670", salaryAmount: 107000, accountNumber: 8819451332],
    [employeeId: 10, employeeName: "Richard Taylor", company: "Walt Disney", ifscCode: "IFSC3847", branchName: "IFSC3847", salaryAmount: 111500, accountNumber: 4550303552]
]

// Create a SQL connection
def sql = Sql.newInstance(jdbcUrl, user, password, 'org.postgresql.Driver')

// Insert each employee's data into the database (table: doc.prasanna)
employees.each { employee ->
    def query = """INSERT INTO doc.prasanna (employeeid, employeename, company, ifsccode, branchname, salaryamount, accountnumber)
                   VALUES (${employee.employeeId}, '${employee.employeeName}', '${employee.company}', '${employee.ifscCode}', '${employee.branchName}', ${employee.salaryAmount}, ${employee.accountNumber})"""
    
    // Execute insert statement with the employee data
    sql.execute(query)
    println "Inserted employee with ID: ${employee.employeeId} into doc.prasanna"
}

// Close the SQL connection
sql.close()
