import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    // Get the XML content from the message body
    def body = message.getBody(String)
    
    // Parse the XML content using XmlSlurper
    def xml = new XmlSlurper().parseText(body)
    
    // Define the namespace mappings if necessary
    def namespaces = [
        m: 'http://schemas.microsoft.com/ado/2007/08/dataservices/metadata',
        d: 'http://schemas.microsoft.com/ado/2007/08/dataservices'
    ]
    
    // Access the value of <d:Customer>
    def customerValue = xml.'**'.find { node -> node.name() == 'd:Customer' && node.namespaceURI == namespaces.d }.text()
    
    // Set the extracted value as a message header
    message.setHeader('CustomerHeaderValue', customerValue)
    
    // Return the modified message
    return message
}
