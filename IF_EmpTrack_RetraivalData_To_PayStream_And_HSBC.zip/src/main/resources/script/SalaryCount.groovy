import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.util.XmlSlurper;

def Message processData(Message message) {
    // Parse the XML payload
    def body = message.getBody(String);
    def xml = new XmlSlurper().parseText(body);
    
    // Initialize counters
    int countEquals50000 = 0;
    int countMoreThan50000 = 0;
    int countLessThan50000 = 0;
    
    // Iterate through Employee nodes and calculate counts
    xml.Employee.each { employee ->
        def salary = employee.SalaryAmount.toInteger();
        if (salary == 50000) {
            countEquals50000++;
        } else if (salary > 50000) {
            countMoreThan50000++;
        } else if (salary < 50000) {
            countLessThan50000++;
        }
    }
    
    // Log the counts as Custom Headers in MPL
    def messageLog = messageLogFactory.getMessageLog(message);
    if (messageLog != null) {
        messageLog.addCustomHeaderProperty("Count_Equal_50000", countEquals50000.toString());
        messageLog.addCustomHeaderProperty("Count_More_Than_50000", countMoreThan50000.toString());
        messageLog.addCustomHeaderProperty("Count_Less_Than_50000", countLessThan50000.toString());
    }
    
    // Return the message
    return message;
}
