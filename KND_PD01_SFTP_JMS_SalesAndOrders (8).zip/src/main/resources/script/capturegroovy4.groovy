import groovy.util.XmlSlurper

// Define the file path
def filePath = 'path/to/your/file.xml'

// Parse the XML file
def xml = new XmlSlurper().parse(new File(filePath))

// Declare namespaces
xml.declareNamespace(
    m: 'http://schemas.microsoft.com/ado/2007/08/dataservices/metadata',
    d: 'http://schemas.microsoft.com/ado/2007/08/dataservices'
)

// Extract the <d:Customer> value
def customerValue = xml.entry.content.'m:properties'.'d:Customer'.text()

// Print the extracted value
println "Customer Value: ${customerValue}"
