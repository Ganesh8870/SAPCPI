import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.XmlSlurper

def Message processData(Message message) {
    // Extract the XML content from the message body
    def xmlString = message.getBody(String) as String
    
    // Check if the XML string is not empty or null
    if (xmlString == null || xmlString.trim().isEmpty()) {
        throw new Exception("The XML content is empty or null.")
    }
    
    // Parse the XML string
    def xml = new XmlSlurper().parseText(xmlString)
    
    // Extract the <d:Customer> value
    def customerValue = xml.'**'.find { it.name() == 'Customer' }?.text()
    
    // Check if customerValue is found
    if (customerValue == null) {
        throw new Exception("The <d:Customer> element is not found in the XML content.")
    }
    
    // Set the value in headers
    message.setHeader('CustomerHeaderValue', customerValue)
    message.setHeader('ShipToAddress', customerValue)
    
    // Return the modified message
    return message
}
