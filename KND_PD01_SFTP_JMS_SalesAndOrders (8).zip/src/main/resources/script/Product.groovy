import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    // Extract the XML content from the message body
    def xmlString = message.getBody(String) as String
    def xml = new XmlSlurper().parseText(xmlString)
    
    // Extract the <d:Customer> value
    def customerValue = xml.'**'.find { it.name() == 'Product' }.text()
    
    // Set the value in a header
    message.setHeader('ProductHeaderValue', customerValue)
   
    
    // Return the modified message
    return message
}
