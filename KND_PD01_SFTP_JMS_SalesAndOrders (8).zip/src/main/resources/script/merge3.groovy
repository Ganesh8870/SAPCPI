import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.*

// Main method to process the message
def Message processData(Message message) {
    // Get the first XML snippet from the message body
    def body = message.getBody(String)
    
    // Split the body to get individual XML parts
    def parts = body.split("\n\n")
    
    // Extract individual XML snippets
    def xml1 = parts[0]
    def xml2 = parts[1]
    
    // Parse the XML snippets
    def parser = new XmlParser()
    def salesOrder = parser.parseText(xml1)
    def items = parser.parseText(xml2)
    
    // Append items to sales order
    salesOrder.append(items)
    
    // Convert the combined XML back to a string
    def writer = new StringWriter()
    def nodePrinter = new XmlNodePrinter(new PrintWriter(writer))
    nodePrinter.setPreserveWhitespace(true)
    nodePrinter.print(salesOrder)
    def result = writer.toString()
    
    // Set the modified payload back to the message
    message.setBody(result)
    
    return message
}
