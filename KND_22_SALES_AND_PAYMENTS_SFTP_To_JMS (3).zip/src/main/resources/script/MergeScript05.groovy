import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.XmlUtil
import groovy.xml.StreamingMarkupBuilder

def Message processData(Message message) {
    // Sample header XML content
    def headerXml = '''
        <Header>
            <SalesOrderType>TA</SalesOrderType>
            <SoldToParty>5000101</SoldToParty>
            <SalesOrganization>KR01</SalesOrganization>
            <DistributionChannel>10</DistributionChannel>
            <OrganizationDivision>00</OrganizationDivision>
            <PurchaseOrderByCustomer>VHCPI03</PurchaseOrderByCustomer>
            <CompleteDeliveryIsDefined>true</CompleteDeliveryIsDefined>
            <_Partner>
                <PartnerFunction>WE</PartnerFunction>
                <Customer>5000103</Customer>
            </_Partner>
        </Header>
    '''

    // Sample incoming XML payload
    def incomingXml = '''
        <Payload>
            <_Item>
                <Product>440000201</Product>
                <RequestedQuantity>6</RequestedQuantity>
                <RequestedQuantityISOUnit>EA</RequestedQuantityISOUnit>
                <StorageLocation>1003</StorageLocation>
                <Plant>2020</Plant>
                <_ItemPricingElement>
                    <ConditionType>ZDIS</ConditionType>
                    <ConditionRateRatio>0</ConditionRateRatio>
                    <ConditionRateRatioISOUnit>P1</ConditionRateRatioISOUnit>
                </_ItemPricingElement>
                <_ItemPricingElement>
                    <ConditionType>ZPR0</ConditionType>
                    <ConditionRateAmount>5</ConditionRateAmount>
                    <ConditionCurrency>USD</ConditionCurrency>
                </_ItemPricingElement>
            </_Item>
            <_Item>
                <Product>440000201</Product>
                <RequestedQuantity>6</RequestedQuantity>
                <RequestedQuantityISOUnit>EA</RequestedQuantityISOUnit>
                <StorageLocation>1003</StorageLocation>
                <Plant>2020</Plant>
                <_ItemPricingElement>
                    <ConditionType>ZDIS</ConditionType>
                    <ConditionRateRatio>0</ConditionRateRatio>
                    <ConditionRateRatioISOUnit>P1</ConditionRateRatioISOUnit>
                </_ItemPricingElement>
                <_ItemPricingElement>
                    <ConditionType>ZPR0</ConditionType>
                    <ConditionRateAmount>5</ConditionRateAmount>
                    <ConditionCurrency>USD</ConditionCurrency>
                </_ItemPricingElement>
            </_Item>
        </Payload>
    '''

    // Parse XML strings into XML objects
    def header = new XmlSlurper().parseText(headerXml)
    def incoming = new XmlSlurper().parseText(incomingXml)

    // Merge the incoming XML into the header XML
    def mergedXml = new StreamingMarkupBuilder().bind {
        mkp.declareNamespace('')
        SalesOrder {
            header.children().each { node ->
                mkp.yield node
            }
            incoming._Item.each { item ->
                mkp.yield item
            }
        }
    }

    // Convert the merged XML back to string format using XmlUtil.serialize for proper formatting
    def mergedXmlString = XmlUtil.serialize(mergedXml)

    // Set the merged XML as the message body
    message.setBody(mergedXmlString)

    return message
}