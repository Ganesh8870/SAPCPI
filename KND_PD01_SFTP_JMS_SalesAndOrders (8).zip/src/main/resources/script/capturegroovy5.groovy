import groovy.util.XmlSlurper

// Define the file path
def filePath = 'C:/path/to/your/file.xml'  // Use an absolute path to avoid confusion

// Check if the file exists
def file = new File(filePath)
if (!file.exists()) {
    println "File not found: ${filePath}"
    return
}

// Parse the XML file
def xml
try {
    xml = new XmlSlurper().parse(file)
} catch (Exception e) {
    println "Error parsing XML file: ${e.message}"
    return
}

// Declare namespaces
xml.declareNamespace(
    m: 'http://schemas.microsoft.com/ado/2007/08/dataservices/metadata',
    d: 'http://schemas.microsoft.com/ado/2007/08/dataservices'
)

// Extract the <d:Customer> value
def customerValue = xml.entry.content.'m:properties'.'d:Customer'.text()

// Print the extracted value
println "Customer Value: ${customerValue}"
