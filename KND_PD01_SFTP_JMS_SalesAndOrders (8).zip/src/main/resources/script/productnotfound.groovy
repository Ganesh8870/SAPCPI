import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    // Extract the XML content from the message body
    def xmlString = message.getBody(String) as String
    def xml = new XmlSlurper().parseText(xmlString)
    
    // Extract the <d:Product> value
    def productValue = xml.'**'.find { it.name() == 'Product' }?.text()
    
    // If product value is null or empty, set it to "notfound"
    if (!productValue) {
        productValue = "ProductNotFound"
    }
    
    // Set the value in a header
    message.setHeader('ProductHeaderValue', productValue)
    
    // Return the modified message
    return message
}
