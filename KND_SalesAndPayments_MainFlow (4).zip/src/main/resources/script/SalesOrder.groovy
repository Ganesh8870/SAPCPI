import com.sap.gateway.ip.core.customdev.util.Message
import java.util.logging.Logger

def Message processData(Message message) {
    Logger log = Logger.getLogger("SalesOrder.groovy")
    
    // Extract the XML content from the message body
    def xmlString = message.getBody(String) as String

    // Log the raw XML string for debugging
    log.info("Raw XML String: $xmlString")

    // Remove any Byte Order Mark (BOM) if present
    if (xmlString.startsWith("\uFEFF")) {
        xmlString = xmlString.substring(1)
    }

    // Trim the XML string to remove leading and trailing whitespace
    xmlString = xmlString.trim()

    // Log the trimmed XML string for debugging
    log.info("Trimmed XML String: $xmlString")

    // Parse the XML content
    def xml
    try {
        xml = new XmlSlurper().parseText(xmlString)
    } catch (Exception e) {
        log.severe("Error parsing XML: $e")
        throw e
    }

    // Extract the <SalesOrder> value
    def salesOrderValue = xml.'**'.find { it.name() == 'SalesOrder' }?.text() ?: 'SalesOrderNotFound'
    
    // Set the value in a header
    message.setHeader('SalesOrder', salesOrderValue)
    
    // Return the modified message
    return message
}
