import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.*

// Main method to process the message
def Message processData(Message message) {
    // Get the XML snippets from message properties
    def xml1 = message.getProperty("XMLPart1")
    def xml2 = message.getProperty("XMLPart2")
    
    if (!xml1 || !xml2) {
        throw new Exception("Both XMLPart1 and XMLPart2 properties must be set.")
    }
    
    // Parse the XML snippets
    def parser = new XmlParser()
    def salesOrder = parser.parseText(xml1)
    def items = parser.parseText(xml2)
    
    // Append items to sales order
    salesOrder.append(items)
    
    // Convert the combined XML back to a string
    def writer = new StringWriter()
    def nodePrinter = new XmlNodePrinter(new PrintWriter(writer))
    nodePrinter.setPreserveWhitespace(true)
    nodePrinter.print(salesOrder)
    def result = writer.toString()
    
    // Set the modified payload back to the message
    message.setBody(result)
    
    return message
}
