import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

Message processData(Message message) {
    // Get the JSON payload from the message body
    def body = message.getBody(String)
    
    // Parse the JSON payload
    def jsonSlurper = new JsonSlurper()
    def jsonObj = jsonSlurper.parseText(body)
    
    // Get the ErrorMessage value from the header
    def errorMessage = message.getHeader("ErrorMessage", String)
    
    // Update the "message" field in the JSON payload
    jsonObj.message = errorMessage
    
    // Convert the updated JSON object back to string
    def updatedJson = JsonOutput.toJson(jsonObj)
    
    // Set the updated JSON payload back to the message body
    message.setBody(updatedJson)
    
    return message
}
