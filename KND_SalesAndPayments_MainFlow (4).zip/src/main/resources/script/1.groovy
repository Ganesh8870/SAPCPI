import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    // Extract the JSON content from the message body
    def jsonString = message.getBody(String) as String
    
    // Parse the JSON content
    def json = new JsonSlurper().parseText(jsonString)
    
    // Extract the SalesOrder value
    def salesOrderValue = json.SalesOrder ?: 'SalesOrderNotFound'
    
    // Set the value in a header
    message.setHeader('SalesOrderNumber', salesOrderValue)
    
    // Return the modified message
    return message
}
