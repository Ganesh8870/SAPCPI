import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {
    // Get the header value
    def salesOrder = message.getHeader("SalesOrder", String)

    // Get the message body as a string
    def body = message.getBody(String)

    // Parse the JSON body
    def jsonSlurper = new JsonSlurper()
    def jsonBody = jsonSlurper.parseText(body)

    // Add the SalesOrder value to the JSON
    jsonBody.SalesOrder = salesOrder

    // Convert the JSON back to a string
    def modifiedBody = JsonOutput.toJson(jsonBody)

    // Set the modified body back to the message
    message.setBody(modifiedBody)

    return message
}
