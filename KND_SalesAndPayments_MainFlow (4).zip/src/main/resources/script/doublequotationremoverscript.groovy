import groovy.json.JsonOutput
import groovy.json.JsonSlurper
import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    // Get the JSON payload from the message body
    def body = message.getBody(String)
    def json = new JsonSlurper().parseText(body)

    // Convert specified fields to their appropriate types
    json.CompleteDeliveryIsDefined = Boolean.valueOf(json.CompleteDeliveryIsDefined)

    json._Item.each { item ->
        item.RequestedQuantity = Integer.valueOf(item.RequestedQuantity)
        item._ItemPricingElement.each { element ->
            if (element.ConditionRateRatio != null) {
                element.ConditionRateRatio = Integer.valueOf(element.ConditionRateRatio)
            }
            if (element.ConditionRateAmount != null) {
                element.ConditionRateAmount = Integer.valueOf(element.ConditionRateAmount)
            }
        }
    }

    // Add square brackets around the _Partner node
    if (!(json._Partner instanceof List)) {
        json._Partner = [json._Partner]
    }

    // Remove the 'SalesOrders' node if it exists
    json.remove("SalesOrders")

    // Convert the modified JSON back to a string
    def jsonOutput = JsonOutput.toJson(json)
    def prettyJsonOutput = JsonOutput.prettyPrint(jsonOutput)

    // Set the modified JSON as the message body
    message.setBody(prettyJsonOutput)
    return message
}
