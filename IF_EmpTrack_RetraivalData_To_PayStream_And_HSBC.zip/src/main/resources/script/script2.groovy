import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
    // Get XML input from the message body
    def body = message.getBody(String) as String;
    def sqlStatement = new StringBuffer();

    // Start the INSERT query
    sqlStatement.append("INSERT INTO doc.prasanna (employeeid, employeename, company, ifsccode, branchname, salaryamount, accountnumber)\nVALUES\n");

    // Parse XML input
    def xml = new XmlSlurper().parseText(body);

    def values = [] // Temporary list to hold each row's values

    // Loop through each Employee node and prepare rows
    xml.Employee.each { employee ->
        def row = new StringBuilder();
        row.append("(");
        row.append(employee.EmployeeID.text() ? employee.EmployeeID.text() : "NULL").append(", "); // EmployeeID
        row.append(employee.EmployeeName.text() ? "'${employee.EmployeeName.text().replace("'", "''").trim()}'" : "NULL").append(", "); // EmployeeName
        row.append(employee.Company.text() ? "'${employee.Company.text().replace("'", "''")}'" : "NULL").append(", "); // Company
        row.append(employee.IFSCCode.text() ? "'${employee.IFSCCode.text().replace("'", "''")}'" : "NULL").append(", "); // IFSCCode
        row.append(employee.BranchName.text() ? "'${employee.BranchName.text().replace("'", "''")}'" : "NULL").append(", "); // BranchName
        row.append(employee.SalaryAmount.text() ? employee.SalaryAmount.text() : "NULL").append(", "); // SalaryAmount
        row.append(employee.AccountNumber.text() ? "'${employee.AccountNumber.text().replace("'", "''")}'" : "NULL"); // AccountNumber
        row.append(")");
        values.add(row.toString());
    }

    // Combine all rows with commas
    sqlStatement.append(values.join(",\n"));
    sqlStatement.append(";"); // End the query with a semicolon

    // Set the generated SQL statements as the message body
    message.setBody(sqlStatement.toString());
    return message;
}
