import java.text.SimpleDateFormat
import java.util.Date
import java.util.TimeZone
import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    // Step 1: Retrieve the previously set properties (GeneratedTime and ExpiryTime)
    String generatedTime = message.getProperty("GeneratedTime")  // Get GeneratedTime
    String expiryTime = message.getProperty("ExpiryTime")        // Get ExpiryTime

    // Step 2: Parse the retrieved GeneratedTime to a Date object (assuming it's in UTC)
    SimpleDateFormat utcDateFormat = new SimpleDateFormat("yyyyMMdd'T'HHmmss")  // Format to match the input
    utcDateFormat.setTimeZone(TimeZone.getTimeZone("UTC")); // Set to UTC

    // Parse the generated time from the property to Date object in UTC
    Date generatedDate = utcDateFormat.parse(generatedTime)

    // Convert generated date to IST
    SimpleDateFormat istDateFormat = new SimpleDateFormat("yyyyMMdd'T'HHmmss")  // Same format for output
    istDateFormat.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata")); // Set to IST

    // Get the current time in IST for comparison
    Date currentTime = new Date(); // This will still be in UTC

    // Get the current IST time
    String currentISTTime = istDateFormat.format(currentTime);
    
    // Print the current IST time (optional for debugging)
    message.setProperty("CurrentISTTime", currentISTTime);

    // Assuming expiryTime is in seconds; convert it to milliseconds
    long expiryInMillis = Long.parseLong(expiryTime) * 1000;  
    Date expiryDate = new Date(generatedDate.getTime() + expiryInMillis);  // Calculate expiry date

    // Step 3: Check if the token is valid (compare expiry time with current time in IST)
    if (currentTime.before(expiryDate)) {
        message.setProperty("TokenValid", "Yes") // Update TokenValid property if still valid
    } else {
        message.setProperty("TokenValid", "No")  // Update TokenValid property if expired
    }

    return message;  // Ensure to return the message at the end
}
