import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.XmlSlurper

def Message process(Message message) {
    // Get the XML content from the message body
    def body = message.getBody(String)
    
    // Parse the XML content
    def xml = new XmlSlurper().parseText(body)
    
    // Declare namespaces if necessary
    xml.declareNamespace(
        m: 'http://schemas.microsoft.com/ado/2007/08/dataservices/metadata',
        d: 'http://schemas.microsoft.com/ado/2007/08/dataservices'
    )
    
    // Extract the <d:Customer> value
    def customerValue = xml.entry.content.'m:properties'.'d:Customer'.text()
    
    // Set the extracted value as a message property
    message.setProperty('CustomerValue', customerValue)
    
    // Return the modified message
    return message
}
