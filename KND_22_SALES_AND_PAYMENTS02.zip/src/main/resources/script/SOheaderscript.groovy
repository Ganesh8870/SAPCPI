import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    // Get the payload as string
    def payload = message.getBody(String.class)
    
    // Parse the payload as JSON
    def json = new groovy.json.JsonSlurper().parseText(payload)
    
    // Extract SalesOrder value
    def salesOrder = json.SalesOrder.toString()  // Ensure to convert to String if needed
    
    // Set SalesOrder as a header field in the message
    message.setHeader('SalesOrder', salesOrder)
    
    // Log the captured SalesOrder for verification
    println "Captured SalesOrder: $salesOrder"
    
    // Return the modified message
    return message
}
