import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;

def Message processData(Message message) {
    // Get the JSON payload as a string
    def body = message.getBody(String);

    // Parse the JSON payload
    def jsonSlurper = new JsonSlurper();
    def jsonObject = jsonSlurper.parseText(body);

    // Check if the "SalesOrder" field exists
    if (jsonObject.SalesOrder != null) {
        // Set the header "Error" with the value "false"
        message.setHeader("Error", 'false');
        message.setHeader("ErrorReason", '');
    } else {
        // Set the header "Error" with the value "true"
        message.setHeader("Error", 'true');

        // Extract the main error message if available
        def errorMessage = jsonObject.error?.message ?: 'Unknown error';
       
        // Set the header "ErrorReason" with the appropriate error reason
        message.setHeader("ErrorReason", errorMessage);
    }

    return message;
}
