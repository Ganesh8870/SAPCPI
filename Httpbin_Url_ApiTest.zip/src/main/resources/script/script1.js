importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
    // Get current time (in seconds)
    var currentTimeInSeconds = Math.floor(new Date().getTime() / 1000);

    // Extract issued_at and expires_in (for demonstration purposes, these are hardcoded)
    var issuedAt = message.getProperty("issue_time"); // Convert milliseconds to seconds
    var expiresIn = message.getProperty("exp_time"); // Token lifespan in seconds

    // Initialize token validity
    var tokenValidity = "No"; // Default to "No"

    // Verify token validity
    if (issuedAt && expiresIn) {
        var tokenExpiryTime = issuedAt + expiresIn;

        if (currentTimeInSeconds <= tokenExpiryTime) {
            tokenValidity = "Yes"; // Token is valid
        }
    }

    // Set the token validity as a property
    message.setProperty("tokenValidity", tokenValidity);

    return message; // Return the message object for further processing in the flow
}
