import com.sap.gateway.ip.core.customdev.util.Message
import java.text.SimpleDateFormat
import java.util.Date
import java.util.HashMap
import java.util.TimeZone

def Message processData(Message message) {
    // Get the current date and time
    def now = new Date()

    // Define the desired format
    def formatter = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss")

    // Set the timezone to IST (Indian Standard Time)
    def istTimeZone = TimeZone.getTimeZone("Asia/Kolkata")
    formatter.setTimeZone(istTimeZone)

    // Format the current date and time
    def formattedDate = formatter.format(now)

    // Set the formatted date as a property
    message.setProperty("CurrentTimestamp", formattedDate)

    // Retrieve the message body as a string
    def body = message.getBody(String)

    // Initialize properties
    def fileName = "Unknown"
    def fileExtension = "Unknown"
    def isEmpty = false

    // Check if the payload is empty
    if (body == null || body.trim().isEmpty()) {
        isEmpty = true
        message.setProperty("EmptyPayload", true)
    } else {
        message.setProperty("EmptyPayload", false)

        // Extract filename from the content-disposition header in multipart data if present
        def headers = message.getHeaders() as HashMap
        def filenameFromMultipart = null
        def pattern = /Content-Disposition: form-data; name="[^"]+"; filename="([^"]+)"/
        def matcher = (body =~ pattern)

        if (matcher.find()) {
            filenameFromMultipart = matcher.group(1) // Extract the filename
            fileName = filenameFromMultipart
        } else if (headers.containsKey("CamelFileName")) {
            // Use CamelFileName if multipart filename is not present
            fileName = headers.get("CamelFileName")
        }

        // Derive file extension if filename is available
        if (fileName != "Unknown" && fileName.contains(".")) {
            fileExtension = fileName.substring(fileName.lastIndexOf('.') + 1)
            fileName = fileName.substring(0, fileName.lastIndexOf('.')) // Remove the extension
        }

        // Append timestamp to the filename
        if (fileName != "Unknown") {
            fileName = fileName + "_" + formattedDate + "." + fileExtension
        } else {
            fileName = "File_" + formattedDate + ".unknown"
        }

        // Set extracted filename and extension as properties
        message.setProperty("FileName", fileName)
        message.setProperty("FileExtension", fileExtension)

        // Extract XML content from the body if multipart data is detected
        if (body.contains("Content-Disposition")) {
            def startIdx = body.indexOf("<name>") // Start of the XML content
            def endIdx = body.lastIndexOf("</age>") + "</age>".length() // End of the XML content

            if (startIdx != -1 && endIdx != -1) {
                body = body.substring(startIdx, endIdx) // Extract just the XML content
            }
        }
    }

    // Set the XML content or original body as the message payload
    message.setBody(body)

    // Add logging for debugging
    def log = messageLogFactory.getMessageLog(message)
    if (log != null) {
        log.addAttachmentAsString("Payload", body, "text/plain")
        log.addAttachmentAsString("FileName", fileName, "text/plain")
        log.addAttachmentAsString("FileExtension", fileExtension, "text/plain")
        log.addAttachmentAsString("IsEmpty", isEmpty.toString(), "text/plain")
    }

    return message
}
