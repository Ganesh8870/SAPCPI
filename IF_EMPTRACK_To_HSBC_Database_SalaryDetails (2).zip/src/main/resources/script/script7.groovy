import com.sap.it.api.msglog.MessageLogFactory;
import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;

def Message processData(Message message) {
    // Create a message log
    def messageLog = MessageLogFactory.getMessageLog(message);

    // Get log level properties
    def logLevel = message.getProperty("SAP_MPL_LogLevel_Overall");
    def logLevelInternal = message.getProperty("SAP_MPL_LogLevel_Internal");
    def logLevelExternal = message.getProperty("SAP_MPL_LogLevel_External");

    // Parse the incoming JSON payload
    def payload = message.getBody(String); // Assuming the body is a String (JSON format)
    def jsonSlurper = new JsonSlurper();
    def employees = jsonSlurper.parseText(payload);

    // Initialize counters for salary categories
    def exactly50000Count = 0;
    def greaterThan50000Count = 0;
    def lessThan50000Count = 0;

    // Categorize employees based on salary
    employees.each { employee ->
        def salary = employee.salaryamount;

        if (salary == 50000) {
            exactly50000Count++;
        } else if (salary > 50000) {
            greaterThan50000Count++;
        } else {
            lessThan50000Count++;
        }
    }

    // Set custom headers for salary categories
    message.setHeader("CustomHeader_Exactly50000", exactly50000Count);
    message.setHeader("CustomHeader_GreaterThan50000", greaterThan50000Count);
    message.setHeader("CustomHeader_LessThan50000", lessThan50000Count);

    // Log custom headers
    messageLog.addCustomHeaderProperty("Log Level", logLevel);
    messageLog.addCustomHeaderProperty("Internal Log Level", logLevelInternal);
    messageLog.addCustomHeaderProperty("External Log Level", logLevelExternal);

    // Add attachments for debugging if log level is DEBUG or TRACE
    if (logLevel == "DEBUG" || logLevel == "TRACE") {
        // Attach the full employee list as JSON
        messageLog.addAttachmentAsString("Employee List", payload, "application/json");
        
        // Add debugging information string
        def debugInfo = """
        Employees Categorized:
        - Exactly Rs. 50000: ${exactly50000Count}
        - Greater than Rs. 50000: ${greaterThan50000Count}
        - Less than Rs. 50000: ${lessThan50000Count}
        """;
        messageLog.addAttachmentAsString("Debugging Information", debugInfo, "text/plain");
    }

    // Return the modified message
    return message;
}
