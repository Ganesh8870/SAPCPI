import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.XmlUtil
import groovy.util.XmlParser

Message processData(Message message) {
    def body = message.getBody(String)
    def wrappedBody = "<root>${body}</root>"  // Wrap the XML with a root element

    def parser = new XmlParser()
    def root
    try {
        root = parser.parseText(wrappedBody)
    } catch (Exception e) {
        throw new RuntimeException("Invalid XML format: " + e.message)
    }
    
    def items = root._Item
    def itemMap = [:]

    items.each { item ->
        def product = item.Product.text()
        if (!itemMap.containsKey(product)) {
            itemMap[product] = item
        } else {
            def existingItem = itemMap[product]
            
            // Handle empty RequestedQuantity
            def existingQuantityStr = existingItem.RequestedQuantity.text()
            def newQuantityStr = item.RequestedQuantity.text()
            
            def existingQuantity = existingQuantityStr ? existingQuantityStr.toInteger() : 0
            def newQuantity = newQuantityStr ? newQuantityStr.toInteger() : 0
            
            existingItem.RequestedQuantity[0].value = (existingQuantity + newQuantity).toString()
            
            def existingPricingElements = existingItem._ItemPricingElement
            def newPricingElements = item._ItemPricingElement

            newPricingElements.each { newPricing ->
                def conditionType = newPricing.ConditionType.text()
                def existingPricing = existingPricingElements.find { it.ConditionType.text() == conditionType }
                if (existingPricing) {
                    // Handle empty ConditionRateAmount
                    def newAmountStr = newPricing.ConditionRateAmount.text()
                    def existingAmountStr = existingPricing.ConditionRateAmount.text()
                    
                    def newAmount = newAmountStr ? newAmountStr.toDouble() : 0
                    def existingAmount = existingAmountStr ? existingAmountStr.toDouble() : 0
                    
                    existingPricing.ConditionRateAmount[0].value = (existingAmount + newAmount).toString()
                } else {
                    existingItem.appendNode(newPricing)
                }
            }
        }
    }

    root._Item = itemMap.values().toList()
    
    // Remove the wrapper root element
    def finalXml = XmlUtil.serialize(root).replaceFirst("<root>", "").replaceFirst("</root>", "")
    message.setBody(finalXml)
    return message
}
