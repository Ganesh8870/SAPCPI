import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    // Access the body of the message
    def body = message.getBody(java.lang.String) as String;
    def messageLog = messageLogFactory.getMessageLog(message);
    def logger = message.getProperty("Enable_Logger");

    // Check if message log is available and logging is enabled
    if (messageLog != null && logger == "true") {
        // Log the message properties
        messageLog.setStringProperty("Logging#1", "Logger is enabled and running");
        
        // Attach the main payload to the log
        messageLog.addAttachmentAsString("EmpTrack_MainPayload", body, "text/plain");

        // Example: Attach an error payload (if available)
        def errorPayload = message.getProperty("ErrorPayload") ?: "No error payload available";
        messageLog.addAttachmentAsString("Error_Payload_Details", errorPayload, "text/plain");

        // Example: Attach error description (if available)
        def errorDescription = message.getProperty("ErrorDescription") ?: "No error description available";
        messageLog.addAttachmentAsString("Error_Description", errorDescription, "text/plain");
        
        // You can also log the status or process checkpoints to ensure proper logging flow
        messageLog.setStringProperty("Logging#2", "Attachments added successfully");
    } else {
        // Log if message log or logger is not enabled
        messageLog.setStringProperty("Logging#1", "Logger is not enabled or message log is null");
    }

    return message;
}
