import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

Message processData(Message message) {
    // Get the body of the message as a string
    def body = message.getBody(String)
    
    // Parse the JSON payload
    def jsonSlurper = new JsonSlurper()
    def jsonObject = jsonSlurper.parseText(body)
    
    // Initialize error flag
    def errorFlag = false
    
    // Check for the presence of the 'error' key in the JSON payload
    if (jsonObject.error) {
        errorFlag = true
    }
    
    // Set the 'Error' field in the message header
    message.setHeader("Error", errorFlag)
    
    return message
}
