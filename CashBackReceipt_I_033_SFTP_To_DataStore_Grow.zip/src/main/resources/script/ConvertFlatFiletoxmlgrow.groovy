import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def messageBody = message.getBody(java.lang.String)
    def lines = messageBody.split('\n')
    
    // Initialize the XML StringBuilder
    def xmlBuilder = new StringBuilder()
    
    // Append the root element
    xmlBuilder.append('<CashbackReceipts>')
    
    // Track if we're inside a CashbackReceipt element
    def insideCashbackReceipt = false
    
    // Loop through each line
    lines.each { line ->
        def parts = line.split(';')
        if (parts[0] == 'T') {
            // Close the previous CashbackReceipt element if necessary
            if (insideCashbackReceipt) {
                xmlBuilder.append('</CashbackReceipt>')
            }
            // Start a new CashbackReceipt for each 'T' line
            xmlBuilder.append('<CashbackReceipt>')
            xmlBuilder.append('<CashbackReceiptheader>')
            parts.eachWithIndex { value, index ->
                switch (index) {
                    case 0:
                        xmlBuilder.append("<Tablereference>${value}</Tablereference>")
                        break
                    case 1:
                        xmlBuilder.append("<Invoicetype>${value}</Invoicetype>")
                        break
                    case 2:
                        xmlBuilder.append("<InvoiceNumber>${value}</InvoiceNumber>")
                        break
                    case 3:
                        xmlBuilder.append("<Customer>${value}</Customer>")
                        break
                    case 4:
                        xmlBuilder.append("<CompanyCode>${value}</CompanyCode>")
                        break
                    case 5:
                        xmlBuilder.append("<Salessite>${value}</Salessite>")
                        break
                    case 6:
                        xmlBuilder.append("<InvoiceDate>${value}</InvoiceDate>")
                        break
                    case 7:
                        xmlBuilder.append("<Currency>${value}</Currency>")
                        break
                    case 8:
                        xmlBuilder.append("<Paybycustomer>${value}</Paybycustomer>")
                        break
                    case 9:
                        xmlBuilder.append("<DueDateBasis>${value}</DueDateBasis>")
                        break
                    case 10:
                        xmlBuilder.append("<AccountingDate>${value}</AccountingDate>")
                        break
                }
            }
            xmlBuilder.append('</CashbackReceiptheader>')
            insideCashbackReceipt = true // We're now inside a CashbackReceipt element
        } else if (parts[0] == 'D') {
            // Add CashbackReceiptheader1 for each 'D' line
            xmlBuilder.append('<CashbackReceiptheader1>')
            parts.eachWithIndex { value, index ->
                switch (index) {
                    case 0:
                        xmlBuilder.append("<Tablereference>${value}</Tablereference>")
                        break
                    case 1:
                        xmlBuilder.append("<Invoiceline>${value}</Invoiceline>")
                        break
                    case 2:
                        xmlBuilder.append("<Salessite>${value}</Salessite>")
                        break
                    case 3:
                        xmlBuilder.append("<Chartofaccountcode>${value}</Chartofaccountcode>")
                        break
                    case 4:
                        xmlBuilder.append("<GLAccount>${value}</GLAccount>")
                        break
                    case 5:
                        xmlBuilder.append("<AccountDistribution>${value}</AccountDistribution>")
                        break
                    case 6:
                        xmlBuilder.append("<Amount>${value}</Amount>")
                        break
                    case 7:
                        xmlBuilder.append("<Nill1>${value}</Nill1>")
                        break
                    case 8:
                        xmlBuilder.append("<Nill2>${value}</Nill2>")
                        break
                    case 9:
                        xmlBuilder.append("<Nill3>${value}</Nill3>")
                        break
                    case 10:
                        xmlBuilder.append("<Nill4>${value}</Nill4>")
                        break
                }
            }
            xmlBuilder.append('</CashbackReceiptheader1>')
        } else if (parts[0] == 'E') {
            // Add CashbackReceiptheader2 for each 'E' line
            xmlBuilder.append('<CashbackReceiptheader2>')
            parts.eachWithIndex { value, index ->
                switch (index) {
                    case 0:
                        xmlBuilder.append("<Tablereference>${value}</Tablereference>")
                        break
                    case 1:
                        xmlBuilder.append("<DueDateNumber>${value}</DueDateNumber>")
                        break
                    case 2:
                        xmlBuilder.append("<DueDate>${value}</DueDate>")
                        break
                    case 3:
                        xmlBuilder.append("<PaymentMethod>${value}</PaymentMethod>")
                        break
                    case 4:
                        xmlBuilder.append("<Paymenttype>${value}</Paymenttype>")
                        break
                    case 5:
                        xmlBuilder.append("<Amount>${value}</Amount>")
                        break
                    case 6:
                        xmlBuilder.append("<Reminder>${value}</Reminder>")
                        break
                    case 7:
                        xmlBuilder.append("<CustomerAddress>${value}</CustomerAddress>")
                        break
                }
            }
            xmlBuilder.append('</CashbackReceiptheader2>')
        }
    }
    
    // Close the last CashbackReceipt element if necessary
    if (insideCashbackReceipt) {
        xmlBuilder.append('</CashbackReceipt>')
    }
    
    // Append the closing root element
    xmlBuilder.append('</CashbackReceipts>')
    
    // Set the XML output to the message body
    message.setBody(xmlBuilder.toString())
    
    return message
}
